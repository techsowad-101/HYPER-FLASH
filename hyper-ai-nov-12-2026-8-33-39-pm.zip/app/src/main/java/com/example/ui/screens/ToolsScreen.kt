package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.HyperLanguage
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidDark
import com.example.viewmodel.MainViewModel

data class AppLaunchItem(
    val key: String,
    val titleEn: String,
    val titleBn: String,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ToolsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val battery by viewModel.batteryInfo.collectAsState()
    val specs by viewModel.deviceSpecs.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isBengali = settings.language == HyperLanguage.BENGALI

    val quickApps = listOf(
        AppLaunchItem("camera", "Camera", "ক্যামেরা", Icons.Default.CameraAlt, NeonCyan),
        AppLaunchItem("youtube", "YouTube", "ইউটিউব", Icons.Default.PlayArrow, NeonRed),
        AppLaunchItem("chrome", "Browser", "ব্রাউজার", Icons.Default.Language, NeonPurple),
        AppLaunchItem("settings", "Settings", "সেটিংস", Icons.Default.Settings, NeonCyan),
        AppLaunchItem("clock", "Alarm/Clock", "অ্যালার্ম/ঘড়ি", Icons.Default.Alarm, NeonAmber),
        AppLaunchItem("calculator", "Calculator", "ক্যালকুলেটর", Icons.Default.Calculate, NeonGreen),
        AppLaunchItem("phone", "Phone Dialer", "ফোন ডায়াল", Icons.Default.Phone, NeonGreen),
        AppLaunchItem("messages", "Messages", "মেসেজ", Icons.Default.Message, NeonCyan),
        AppLaunchItem("maps", "Google Maps", "ম্যাপ", Icons.Default.Map, NeonAmber),
        AppLaunchItem("playstore", "Play Store", "প্লে স্টোর", Icons.Default.Shop, NeonPink)
    )

    val quickSettings = listOf(
        Triple("wifi", if (isBengali) "ওয়াইফাই" else "Wi-Fi", Icons.Default.Wifi),
        Triple("bluetooth", if (isBengali) "ব্লুটুথ" else "Bluetooth", Icons.Default.Bluetooth),
        Triple("display", if (isBengali) "ডিসপ্লে" else "Display", Icons.Default.Wallpaper),
        Triple("sound", if (isBengali) "শব্দ ও ভলিউম" else "Sound", Icons.Default.VolumeUp),
        Triple("battery", if (isBengali) "ব্যাটারি অপ্টিমাইজ" else "Battery", Icons.Default.BatteryChargingFull),
        Triple("apps", if (isBengali) "অ্যাপস লিস্ট" else "Apps", Icons.Default.Devices)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(VoidDark)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("tools_screen")
    ) {
        // Top Section: Title & Refresh Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isBengali) "ফোন কমান্ড ও টুলস" else "PHONE COMMANDS & TOOLS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = if (isBengali) "সরাসরি অ্যান্ড্রয়েড সিস্টেম এপিআই দ্বারা নিয়ন্ত্রিত" else "Direct hardware & OS integrations",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMuted
                    )
                )
            }

            IconButton(
                onClick = { viewModel.refreshTelemetry() },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(CyberSurface)
                    .border(1.dp, CyberBorder, CircleShape)
                    .testTag("refresh_tools_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh",
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. BATTERY TELEMETRY CARD
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF131A33),
                            Color(0xFF0F2629)
                        )
                    )
                )
                .border(1.dp, Color(0x5500F0FF), RoundedCornerShape(16.dp))
                .padding(16.dp)
                .testTag("battery_info_card")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Battery Percent Gauge
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(
                            if (battery.isCharging) Color(0xFF00382B) else Color(0xFF132238)
                        )
                        .border(
                            2.dp,
                            if (battery.isCharging) NeonGreen else NeonCyan,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${battery.percentage}%",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = if (battery.isCharging) NeonGreen else Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (battery.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                            contentDescription = "Battery Status",
                            tint = if (battery.isCharging) NeonGreen else NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBengali) "ব্যাটারি স্থিতি" else "Battery Diagnostics",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (isBengali)
                            "অবস্থা: ${if (battery.isCharging) "চার্জ হচ্ছে (${battery.chargingSource})" else "ব্যাটারিতে চলছে"}"
                        else
                            "Status: ${if (battery.isCharging) "Charging (${battery.chargingSource})" else "Discharging"}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    )

                    Text(
                        text = if (isBengali)
                            "স্বাস্থ্য: ${battery.health} • তাপমাত্রা: ${battery.temperatureCelsius}°C"
                        else
                            "Health: ${battery.health} • Temp: ${battery.temperatureCelsius}°C",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. DEVICE SPECS CARD
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF24103B),
                            Color(0xFF130E2E)
                        )
                    )
                )
                .border(1.dp, Color(0x55BD00FF), RoundedCornerShape(16.dp))
                .padding(16.dp)
                .testTag("device_specs_card")
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Devices,
                        contentDescription = "Device Specs",
                        tint = NeonPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBengali) "ডিভাইস ও সিস্টেম তথ্য" else "Device & OS Specifications",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isBengali) "মডেল" else "Model",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                        )
                        Text(
                            text = "${specs.manufacturer} ${specs.model}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                    Column {
                        Text(
                            text = if (isBengali) "অ্যান্ড্রয়েড ভার্সন" else "Android OS",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                        )
                        Text(
                            text = "v${specs.androidVersion} (API ${specs.apiLevel})",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NeonPurple,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                    Column {
                        Text(
                            text = if (isBengali) "র‍্যাম মেমোরি" else "Available RAM",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                        )
                        Text(
                            text = "${specs.availableRamMb} MB",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = NeonCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. LAUNCH APPS SECTION
        Text(
            text = if (isBengali) "অ্যাপ্লিকেশন লঞ্চার:" else "OPEN INSTALLED APPS:",
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            quickApps.forEach { appItem ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(CyberSurface)
                        .border(1.dp, CyberBorder, RoundedCornerShape(14.dp))
                        .clickable {
                            viewModel.triggerQuickApp(appItem.key)
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                        .testTag("app_launch_${appItem.key}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = appItem.icon,
                            contentDescription = appItem.titleEn,
                            tint = appItem.color,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBengali) appItem.titleBn else appItem.titleEn,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. SYSTEM SETTINGS SHORTCUTS
        Text(
            text = if (isBengali) "ফোন সেটিংস শর্টকাট:" else "PHONE SETTINGS SHORTCUTS:",
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            quickSettings.forEach { (key, title, icon) ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF191338))
                        .border(1.dp, CyberBorder, RoundedCornerShape(14.dp))
                        .clickable {
                            viewModel.triggerQuickSettings(key)
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                        .testTag("setting_shortcut_$key")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.5.sp
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
