package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HyperDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = TextOnCyan,
    primaryContainer = Color(0xFF00363D),
    onPrimaryContainer = NeonCyan,

    secondary = NeonPurple,
    onSecondary = TextOnPurple,
    secondaryContainer = Color(0xFF38004D),
    onSecondaryContainer = Color(0xFFF3C9FF),

    tertiary = NeonPurpleVariant,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF2E0954),
    onTertiaryContainer = Color(0xFFE5C8FF),

    background = VoidDark,
    onBackground = TextPrimary,

    surface = CyberDark,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurface,
    onSurfaceVariant = TextSecondary,

    outline = CyberBorder,
    outlineVariant = CyberBorderNeon,

    error = NeonRed,
    onError = Color.White
)

@Composable
fun HyperAiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // HYPER AI is crafted as a premium futuristic dark-space neon experience
    MaterialTheme(
        colorScheme = HyperDarkColorScheme,
        typography = Typography,
        content = content
    )
}
