package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleVariant
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

@Composable
fun AnimatedAiOrb(
    state: OrbState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    audioAmplitude: Float = 0f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    // Slow continuous rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Breathing pulse
    val breathingPulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // Fast ripple for listening/speaking
    val fastRipple by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fast_ripple"
    )

    // Thinking vortex speed
    val vortexSpin by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "vortex"
    )

    Box(
        modifier = modifier
            .size(size)
            .testTag("ai_animated_orb"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2f) * 0.72f

            // Dynamic scale influenced by audio amplitude and state
            val amplitudeFactor = when (state) {
                OrbState.LISTENING -> (1f + (audioAmplitude * 0.45f))
                OrbState.SPEAKING -> (1f + (sin(fastRipple * 2 * PI).toFloat() * 0.18f).coerceAtLeast(0f))
                OrbState.THINKING -> 1.04f
                OrbState.IDLE -> breathingPulse
            }

            val currentRadius = baseRadius * amplitudeFactor

            // 1. OUTER GLOWING HALO
            val outerHaloRadius = currentRadius * 1.35f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        when (state) {
                            OrbState.LISTENING -> NeonCyan.copy(alpha = 0.35f)
                            OrbState.THINKING -> NeonPurple.copy(alpha = 0.4f)
                            OrbState.SPEAKING -> NeonPink.copy(alpha = 0.35f)
                            OrbState.IDLE -> NeonPurple.copy(alpha = 0.22f)
                        },
                        Color.Transparent
                    ),
                    center = center,
                    radius = outerHaloRadius
                ),
                radius = outerHaloRadius,
                center = center
            )

            // 2. CONCENTRIC RIPPLE WAVES (When active)
            if (state == OrbState.LISTENING || state == OrbState.SPEAKING) {
                val rippleRadius = currentRadius + (fastRipple * baseRadius * 0.5f)
                val rippleAlpha = (1f - fastRipple) * 0.7f
                drawCircle(
                    color = (if (state == OrbState.LISTENING) NeonCyan else NeonPurple).copy(alpha = rippleAlpha),
                    radius = rippleRadius,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }

            // 3. SINE-WAVE CYBERNETIC MESH RINGS
            val waveCount = 8
            val path = Path()
            val angleStep = (2 * PI) / 72.0

            val currentSpin = if (state == OrbState.THINKING) vortexSpin else rotation
            val spinRadians = Math.toRadians(currentSpin.toDouble())

            for (i in 0..72) {
                val theta = i * angleStep + spinRadians
                val waveOffset = when (state) {
                    OrbState.LISTENING -> sin(theta * waveCount + (fastRipple * 2 * PI)) * (12f + audioAmplitude * 20f)
                    OrbState.SPEAKING -> cos(theta * waveCount * 1.5 + (fastRipple * 2 * PI)) * 14f
                    OrbState.THINKING -> sin(theta * 6 + (vortexSpin * 0.1)) * 10f
                    OrbState.IDLE -> sin(theta * waveCount) * 5f
                }
                val r = currentRadius + waveOffset.toFloat()
                val x = center.x + (r * cos(theta)).toFloat()
                val y = center.y + (r * sin(theta)).toFloat()

                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()

            // Draw outer neon wave ring
            drawPath(
                path = path,
                brush = Brush.sweepGradient(
                    colors = listOf(
                        NeonCyan,
                        NeonPurple,
                        NeonPink,
                        NeonCyan
                    ),
                    center = center
                ),
                style = Stroke(width = 4.dp.toPx())
            )

            // 4. INNER ENERGY CORE
            val coreGradient = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.95f),
                    when (state) {
                        OrbState.LISTENING -> NeonCyan
                        OrbState.THINKING -> NeonPurple
                        OrbState.SPEAKING -> NeonPink
                        OrbState.IDLE -> NeonCyan
                    },
                    NeonPurpleVariant.copy(alpha = 0.85f),
                    Color(0xFF0F0B24)
                ),
                center = center,
                radius = currentRadius * 0.85f
            )

            drawCircle(
                brush = coreGradient,
                radius = currentRadius * 0.82f,
                center = center
            )

            // 5. ORBITING NODES / DATA PARTICLES
            val particleCount = 6
            for (p in 0 until particleCount) {
                val orbitRadius = currentRadius * 1.15f
                val orbitAngle = (p * (2 * PI / particleCount)) - spinRadians * 1.2
                val px = center.x + (orbitRadius * cos(orbitAngle)).toFloat()
                val py = center.y + (orbitRadius * sin(orbitAngle)).toFloat()

                drawCircle(
                    color = if (p % 2 == 0) NeonCyan else NeonPink,
                    radius = (4.dp.toPx() * (if (state == OrbState.LISTENING) 1.5f else 1f)),
                    center = Offset(px, py)
                )

                // Thin connector lines to center
                drawLine(
                    color = (if (p % 2 == 0) NeonCyan else NeonPurple).copy(alpha = 0.25f),
                    start = center,
                    end = Offset(px, py),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // 6. INNER SPARKLE CORE
            drawCircle(
                color = Color.White.copy(alpha = 0.8f),
                radius = (12.dp.toPx() * (if (state == OrbState.LISTENING) (1f + audioAmplitude) else 1f)),
                center = center
            )
        }
    }
}
