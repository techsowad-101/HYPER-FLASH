package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Purple and Cyan Neon Palette
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanVariant = Color(0xFF00B8D4)
val NeonCyanGlow = Color(0x6600F0FF)

val NeonPurple = Color(0xFFBD00FF)
val NeonPurpleVariant = Color(0xFF7928CA)
val NeonPurpleGlow = Color(0x66BD00FF)

val NeonPink = Color(0xFFFF007A)
val NeonGreen = Color(0xFF00FF9D)
val NeonAmber = Color(0xFFFFB800)
val NeonRed = Color(0xFFFF3366)

// Dark Cyberpunk Surface & Backgrounds
val VoidDark = Color(0xFF080612)
val CyberDark = Color(0xFF0F0B24)
val CyberSurface = Color(0xFF161138)
val CyberSurfaceVariant = Color(0xFF221A4C)
val CyberBorder = Color(0xFF332766)
val CyberBorderNeon = Color(0x5500F0FF)

// Text Colors
val TextPrimary = Color(0xFFF3F0FF)
val TextSecondary = Color(0xFFB0A4D6)
val TextMuted = Color(0xFF726896)
val TextOnCyan = Color(0xFF04121A)
val TextOnPurple = Color(0xFFFFFFFF)
