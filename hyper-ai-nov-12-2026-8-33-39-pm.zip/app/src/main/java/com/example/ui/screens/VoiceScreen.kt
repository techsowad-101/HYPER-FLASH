package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.local.HyperLanguage
import com.example.ui.components.AnimatedAiOrb
import com.example.ui.components.OrbState
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidDark
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoiceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val orbState by viewModel.orbState.collectAsState()
    val isListening by viewModel.voiceManager.isListening.collectAsState()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsState()
    val audioAmplitude by viewModel.voiceManager.audioAmplitude.collectAsState()
    val transcript by viewModel.voiceManager.transcript.collectAsState()
    val voiceError by viewModel.voiceManager.error.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isBengali = settings.language == HyperLanguage.BENGALI

    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasAudioPermission = isGranted
        if (isGranted) {
            viewModel.startVoiceInput()
        }
    }

    val statusTitle = when (orbState) {
        OrbState.LISTENING -> if (isBengali) "শুনছি... বলুন" else "LISTENING TO VOICE..."
        OrbState.THINKING -> if (isBengali) "প্রসেস হচ্ছে..." else "PROCESSING COMMAND..."
        OrbState.SPEAKING -> if (isBengali) "বলছি..." else "HYPER AI IS SPEAKING..."
        OrbState.IDLE -> if (isBengali) "কথা বলতে মাইকে চাপ দিন" else "TAP MIC TO SPEAK"
    }

    val quickPrompts = if (isBengali) {
        listOf(
            "ব্যাটারি লেভেল কত?",
            "ক্যামেরা খোলো",
            "বর্তমান সময় কত?",
            "ইউটিউব খোলো",
            "ফোন ইনফো দেখাও",
            "ক্যালকুলেট ২৫ * ৪"
        )
    } else {
        listOf(
            "What is my battery level?",
            "Open Camera",
            "What time is it?",
            "Open YouTube",
            "Show device specs",
            "Calculate 120 / 4"
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        VoidDark,
                        CyberDark,
                        Color(0xFF110B29)
                    )
                )
            )
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("voice_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Status Header Pill
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    when (orbState) {
                        OrbState.LISTENING -> Color(0xFF00383D)
                        OrbState.THINKING -> Color(0xFF38004D)
                        OrbState.SPEAKING -> Color(0xFF3B0024)
                        OrbState.IDLE -> Color(0xFF1E1742)
                    }
                )
                .border(
                    1.dp,
                    when (orbState) {
                        OrbState.LISTENING -> NeonCyan
                        OrbState.THINKING -> NeonPurple
                        OrbState.SPEAKING -> NeonPink
                        OrbState.IDLE -> CyberBorder
                    },
                    RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            when (orbState) {
                                OrbState.LISTENING -> NeonCyan
                                OrbState.THINKING -> NeonPurple
                                OrbState.SPEAKING -> NeonPink
                                OrbState.IDLE -> NeonGreen
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusTitle,
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Center Animated AI Orb
        AnimatedAiOrb(
            state = orbState,
            audioAmplitude = audioAmplitude,
            size = 230.dp,
            modifier = Modifier.padding(12.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Live Transcript or Status message
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CyberSurface.copy(alpha = 0.85f))
                .border(1.dp, CyberBorder, RoundedCornerShape(16.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (transcript.isNotBlank()) {
                        "“$transcript”"
                    } else if (isListening) {
                        if (isBengali) "আপনার কণ্ঠ শনাক্ত করা হচ্ছে..." else "Listening for speech..."
                    } else if (isSpeaking) {
                        if (isBengali) "অডিও আউটপুট চলছে..." else "Speaking response..."
                    } else {
                        if (isBengali) "হাইপার এআই আপনার সেবায় প্রস্তুত" else "HYPER AI Voice Engine Ready"
                    },
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = if (transcript.isNotBlank()) NeonCyan else TextSecondary,
                        fontWeight = if (transcript.isNotBlank()) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        fontSize = 15.sp
                    )
                )

                if (voiceError != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = voiceError ?: "",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NeonRed,
                            textAlign = TextAlign.Center
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Main Controls: Big Mic Button & Stop Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Stop button (visible when speaking or listening)
            AnimatedVisibility(
                visible = isSpeaking || isListening,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                IconButton(
                    onClick = {
                        viewModel.stopSpeaking()
                        viewModel.stopVoiceInput()
                    },
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2E0916))
                        .border(1.5.dp, NeonRed, CircleShape)
                        .testTag("stop_voice_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop",
                        tint = NeonRed,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            if (isSpeaking || isListening) {
                Spacer(modifier = Modifier.width(20.dp))
            }

            // Big Glowing Mic Button
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(
                        if (isListening) {
                            Brush.linearGradient(listOf(NeonCyan, Color(0xFF00838F)))
                        } else {
                            Brush.linearGradient(listOf(NeonPurple, NeonPink))
                        }
                    )
                    .border(
                        width = 2.dp,
                        color = if (isListening) NeonCyan else NeonPink,
                        shape = CircleShape
                    )
                    .clickable {
                        if (isListening) {
                            viewModel.stopVoiceInput()
                        } else {
                            if (hasAudioPermission) {
                                viewModel.startVoiceInput()
                            } else {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                    .testTag("voice_mic_fab"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Quick Suggestion Chips
        Text(
            text = if (isBengali) "কুইক কমান্ড ট্রাই করুন:" else "TRY VOICE COMMANDS:",
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            ),
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickPrompts.forEach { prompt ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF191338))
                        .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                        .clickable {
                            viewModel.sendMessage(prompt, fromVoice = true)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("quick_command_chip")
                ) {
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
