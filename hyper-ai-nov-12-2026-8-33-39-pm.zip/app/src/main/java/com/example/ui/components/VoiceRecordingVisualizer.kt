package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VoidDark
import kotlin.math.sin

@Composable
fun ActiveRecordingMicButton(
    isListening: Boolean,
    audioAmplitude: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")

    val pulse1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "p1"
    )

    val pulse2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, delayMillis = 400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "p2"
    )

    Box(
        modifier = modifier
            .size(54.dp)
            .testTag("chat_mic_button"),
        contentAlignment = Alignment.Center
    ) {
        // Concentric Expanding Neon Glow Rings when listening
        if (isListening) {
            Canvas(modifier = Modifier.size(54.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.minDimension / 2f * 0.7f

                // Pulse Ring 1
                val r1 = baseRadius + (pulse1 * (size.minDimension / 2f - baseRadius))
                val a1 = (1f - pulse1) * 0.7f
                drawCircle(
                    color = NeonCyan.copy(alpha = a1),
                    radius = r1,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Pulse Ring 2
                val r2 = baseRadius + (pulse2 * (size.minDimension / 2f - baseRadius))
                val a2 = (1f - pulse2) * 0.6f
                drawCircle(
                    color = NeonPink.copy(alpha = a2),
                    radius = r2,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )
            }
        }

        // Core Mic Button
        val buttonSize = if (isListening) (44.dp + (audioAmplitude * 6).dp) else 44.dp
        Box(
            modifier = Modifier
                .size(buttonSize)
                .clip(CircleShape)
                .background(
                    if (isListening) {
                        Brush.linearGradient(listOf(NeonCyan, NeonPink))
                    } else {
                        Brush.linearGradient(listOf(Color(0xFF22174C), Color(0xFF140E33)))
                    }
                )
                .border(
                    width = if (isListening) 2.dp else 1.dp,
                    color = if (isListening) NeonCyan else CyberBorder,
                    shape = CircleShape
                )
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                contentDescription = if (isListening) "Stop Listening" else "Start Voice Input",
                tint = if (isListening) Color.White else NeonCyan,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun AudioWaveformVisualizer(
    amplitude: Float,
    isListening: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 16
) {
    val transition = rememberInfiniteTransition(label = "waveform_anim")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Row(
        modifier = modifier
            .height(28.dp)
            .testTag("audio_waveform_visualizer"),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until barCount) {
            val normalizedIndex = i.toFloat() / barCount
            val harmonic = sin(phase + normalizedIndex * 4.0).toFloat().coerceIn(-1f, 1f)

            // Calculate animated height
            val targetHeightDp = if (isListening) {
                val waveHeight = 6f + (amplitude * 18f) * (0.4f + 0.6f * kotlin.math.abs(harmonic))
                waveHeight.coerceIn(4f, 26f)
            } else {
                3f
            }

            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(targetHeightDp.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        if (isListening) {
                            if (i % 2 == 0) NeonCyan else NeonPink
                        } else {
                            TextMuted
                        }
                    )
            )
        }
    }
}

@Composable
fun ActiveRecordingBanner(
    isListening: Boolean,
    transcript: String,
    audioAmplitude: Float,
    onCancel: () -> Unit,
    onSubmit: () -> Unit,
    isBengali: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isListening,
        enter = expandVertically(animationSpec = tween(250, easing = FastOutSlowInEasing)) + fadeIn(),
        exit = shrinkVertically(animationSpec = tween(200, easing = FastOutSlowInEasing)) + fadeOut(),
        modifier = modifier.fillMaxWidth()
    ) {
        val blinkTransition = rememberInfiniteTransition(label = "rec_blink")
        val recAlpha by blinkTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "rec_alpha"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF0F1B2E),
                            Color(0xFF1E0F33)
                        )
                    )
                )
                .border(1.dp, Color(0x6600F0FF), RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("active_recording_banner")
        ) {
            Column {
                // Header row: REC indicator, Waveform, and Cancel/Submit buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // REC status pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2E0916))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(NeonRed.copy(alpha = recAlpha))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBengali) "রেকর্ডিং..." else "REC LIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NeonRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }

                    // Live animated soundwave visualizer
                    AudioWaveformVisualizer(
                        amplitude = audioAmplitude,
                        isListening = isListening,
                        barCount = 14,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    // Control buttons: Cancel and Submit
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Cancel button
                        IconButton(
                            onClick = onCancel,
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF26182D))
                                .testTag("cancel_recording_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel recording",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Submit button
                        IconButton(
                            onClick = onSubmit,
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(NeonCyan)
                                .testTag("submit_recording_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Confirm & Send",
                                tint = VoidDark,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Real-time voice transcript text
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (transcript.isNotBlank()) {
                            "“$transcript”"
                        } else {
                            if (isBengali) "স্পষ্ট করে কথা বলুন..." else "Listening... speak now"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (transcript.isNotBlank()) NeonCyan else TextMuted,
                            fontWeight = if (transcript.isNotBlank()) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 12.5.sp
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
