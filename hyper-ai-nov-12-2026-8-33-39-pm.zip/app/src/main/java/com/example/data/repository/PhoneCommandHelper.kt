package com.example.data.repository

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BatteryInfo(
    val percentage: Int,
    val isCharging: Boolean,
    val chargingSource: String,
    val health: String,
    val temperatureCelsius: Float
)

data class DeviceSpecs(
    val model: String,
    val manufacturer: String,
    val androidVersion: String,
    val apiLevel: Int,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val uptimeFormatted: String
)

class PhoneCommandHelper(private val context: Context) {

    fun getBatteryInfo(): BatteryInfo {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, filter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percentage = if (level >= 0 && scale > 0) (level * 100) / scale else 0

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val chargePlug = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val chargingSource = when (chargePlug) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Wall Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Port"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Dock"
            else -> if (isCharging) "Charging" else "On Battery"
        }

        val healthCode = batteryStatus?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Critical/Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            else -> "Normal"
        }

        val tempRaw = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempCelsius = tempRaw / 10.0f

        return BatteryInfo(percentage, isCharging, chargingSource, health, tempCelsius)
    }

    fun getDeviceSpecs(): DeviceSpecs {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        val uptimeMillis = SystemClock.elapsedRealtime()
        val hours = uptimeMillis / (1000 * 60 * 60)
        val minutes = (uptimeMillis % (1000 * 60 * 60)) / (1000 * 60)
        val uptimeFormatted = "${hours}h ${minutes}m"

        return DeviceSpecs(
            model = Build.MODEL,
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT,
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            uptimeFormatted = uptimeFormatted
        )
    }

    fun getCurrentDateTime(language: String): String {
        val locale = if (language == "bn") Locale("bn", "BD") else Locale.US
        val timeFormat = SimpleDateFormat("hh:mm:ss a", locale)
        val dateFormat = SimpleDateFormat("EEEE, MMMM dd, yyyy", locale)
        val now = Date()

        return if (language == "bn") {
            "বর্তমান সময়: ${timeFormat.format(now)}\nআজকের তারিখ: ${dateFormat.format(now)}"
        } else {
            "Current Time: ${timeFormat.format(now)}\nDate: ${dateFormat.format(now)}"
        }
    }

    fun openApp(appKey: String): Pair<Boolean, String> {
        val pm = context.packageManager
        val intent: Intent? = when (appKey.lowercase()) {
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "youtube" -> pm.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            "chrome", "browser" -> pm.getLaunchIntentForPackage("com.android.chrome")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
            "settings" -> Intent(Settings.ACTION_SETTINGS)
            "clock", "alarm" -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            "calculator" -> getCalculatorIntent()
            "phone", "dialer" -> Intent(Intent.ACTION_DIAL)
            "messages", "sms" -> Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_APP_MESSAGING)
            }
            "maps" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=nearby"))
            "playstore", "store" -> pm.getLaunchIntentForPackage("com.android.vending")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store"))
            else -> null
        }

        if (intent == null) {
            return Pair(false, "Could not locate app handler for $appKey")
        }

        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            Pair(true, "Opening $appKey...")
        } catch (e: Exception) {
            Pair(false, "Failed to launch $appKey: ${e.message}")
        }
    }

    private fun getCalculatorIntent(): Intent {
        val calcPackages = listOf(
            "com.google.android.calculator",
            "com.android.calculator2",
            "com.sec.android.app.popupcalculator",
            "com.miui.calculator"
        )
        for (pkg in calcPackages) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) return intent
        }
        return Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_APP_CALCULATOR)
        }
    }

    fun openSettingsScreen(type: String): Pair<Boolean, String> {
        val action = when (type.lowercase()) {
            "wifi", "wireless" -> Settings.ACTION_WIRELESS_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "app_details" -> {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                return try {
                    context.startActivity(intent)
                    Pair(true, "Opening App Details Settings")
                } catch (e: Exception) {
                    Pair(false, "Failed: ${e.message}")
                }
            }
            else -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
            Pair(true, "Opening $type Settings")
        } catch (e: Exception) {
            Pair(false, "Failed to open settings: ${e.message}")
        }
    }
}
