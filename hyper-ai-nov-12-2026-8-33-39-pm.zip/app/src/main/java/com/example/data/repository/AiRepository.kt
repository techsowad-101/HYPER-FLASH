package com.example.data.repository

import com.example.data.local.AiPersonality
import com.example.data.local.HyperLanguage
import kotlinx.coroutines.delay
import java.util.Locale

data class AiResponse(
    val text: String,
    val isOffline: Boolean,
    val action: String? = null,
    val actionTarget: String? = null,
    val bannerNotice: String? = null
)

data class OfflineCommandResult(
    val actionType: String, // "APP", "SETTINGS", "BATTERY", "TIME", "SPECS", "GREETING", "MATH"
    val replyText: String,
    val target: String? = null
)

interface AiRepository {
    fun checkOfflineCommand(query: String, language: HyperLanguage): OfflineCommandResult?
    suspend fun processQuery(
        prompt: String,
        personality: AiPersonality,
        language: HyperLanguage
    ): AiResponse
}

class AiRepositoryImpl(
    private val phoneCommandHelper: PhoneCommandHelper
) : AiRepository {

    override fun checkOfflineCommand(query: String, language: HyperLanguage): OfflineCommandResult? {
        val clean = query.trim().lowercase(Locale.ROOT)
        val isBengali = language == HyperLanguage.BENGALI || containsBengali(clean)

        // 1. GREETINGS
        if (clean in listOf("hi", "hello", "hey", "hey hyper", "good morning", "good evening", "good night", "who are you") ||
            clean.contains("কেমন আছো") || clean.contains("হ্যালো") || clean.contains("হাই") ||
            clean.contains("নমস্কার") || clean.contains("শুভ সকাল") || clean.contains("তুমি কে")
        ) {
            val reply = if (isBengali) {
                "নমস্কার! আমি হাইপার এআই (HYPER AI)। আপনার শক্তিশালী অফলাইন ও অনলাইন সহকারী। আমি কীভাবে আপনাকে সাহায্য করতে পারি?"
            } else {
                "Greetings! I am HYPER AI, your futuristic assistant. All core phone systems and offline brains are fully operational. How may I assist you?"
            }
            return OfflineCommandResult("GREETING", reply)
        }

        // 2. TIME & DATE
        if (clean.contains("time") || clean.contains("date") || clean.contains("clock") ||
            clean.contains("সময়") || clean.contains("তারিখ") || clean.contains("কয়টা বাজে")
        ) {
            val timeString = phoneCommandHelper.getCurrentDateTime(if (isBengali) "bn" else "en")
            return OfflineCommandResult("TIME", timeString)
        }

        // 3. BATTERY
        if (clean.contains("battery") || clean.contains("charge") || clean.contains("power") ||
            clean.contains("ব্যাটারি") || clean.contains("চার্জ")
        ) {
            val bat = phoneCommandHelper.getBatteryInfo()
            val reply = if (isBengali) {
                "ব্যাটারি লেভেল: ${bat.percentage}%\nচার্জিং অবস্থা: ${if (bat.isCharging) "চার্জ হচ্ছে (${bat.chargingSource})" else "ব্যাটারিতে চলছে"}\nস্বাস্থ্য: ${bat.health}\nতাপমাত্রা: ${bat.temperatureCelsius}°C"
            } else {
                "Battery Level: ${bat.percentage}%\nStatus: ${if (bat.isCharging) "Charging (${bat.chargingSource})" else "Discharging"}\nHealth: ${bat.health}\nTemperature: ${bat.temperatureCelsius}°C"
            }
            return OfflineCommandResult("BATTERY", reply)
        }

        // 4. DEVICE SPECS / INFO
        if (clean.contains("device info") || clean.contains("phone info") || clean.contains("specs") ||
            clean.contains("system info") || clean.contains("ডিভাইস") || clean.contains("ফোন তথ্য")
        ) {
            val specs = phoneCommandHelper.getDeviceSpecs()
            val reply = if (isBengali) {
                "ডিভাইস মডেল: ${specs.manufacturer} ${specs.model}\nঅ্যান্ড্রয়েড ভার্সন: ${specs.androidVersion} (API ${specs.apiLevel})\nর‍্যাম: ${specs.availableRamMb} MB খালি / ${specs.totalRamMb} MB মোট\nআপটাইম: ${specs.uptimeFormatted}"
            } else {
                "Device: ${specs.manufacturer} ${specs.model}\nAndroid Version: ${specs.androidVersion} (API ${specs.apiLevel})\nMemory: ${specs.availableRamMb} MB free / ${specs.totalRamMb} MB total\nSystem Uptime: ${specs.uptimeFormatted}"
            }
            return OfflineCommandResult("SPECS", reply)
        }

        // 5. OPEN APPS
        val appMatches = mapOf(
            "camera" to listOf("camera", "ক্যামেরা"),
            "youtube" to listOf("youtube", "ইউটিউব"),
            "chrome" to listOf("chrome", "browser", "google", "ক্রোম", "ব্রাউজার"),
            "settings" to listOf("settings", "সেটিংস"),
            "clock" to listOf("alarm", "clock", "timer", "অ্যালার্ম", "ঘড়ি"),
            "calculator" to listOf("calculator", "ক্যালকুলেটর"),
            "phone" to listOf("dialer", "phone", "call", "ফোন", "ডায়াল"),
            "messages" to listOf("messages", "sms", "মেসেজ"),
            "maps" to listOf("maps", "navigation", "ম্যাপ", "গুগল ম্যাপ"),
            "playstore" to listOf("play store", "app store", "প্লে স্টোর")
        )

        for ((appKey, keywords) in appMatches) {
            val isMatch = keywords.any { kw ->
                clean.contains("open $kw") || clean.contains("launch $kw") ||
                        clean.contains("$kw খোলো") || clean.contains("$kw চালু কর") ||
                        (clean.startsWith("open") && clean.contains(kw))
            }
            if (isMatch) {
                val (success, message) = phoneCommandHelper.openApp(appKey)
                val reply = if (success) {
                    if (isBengali) "$appKey অ্যাপ্লিকেশন চালু করা হচ্ছে..." else "Launching $appKey..."
                } else {
                    if (isBengali) "$appKey চালু করতে সমস্যা হয়েছে: $message" else "Could not open $appKey: $message"
                }
                return OfflineCommandResult("APP", reply, target = appKey)
            }
        }

        // 6. OPEN SPECIFIC SETTINGS
        val settingsMatches = mapOf(
            "wifi" to listOf("wifi", "wi-fi", "ওয়াইফাই"),
            "bluetooth" to listOf("bluetooth", "ব্লুটুথ"),
            "display" to listOf("display", "brightness", "ডিসপ্লে", "উজ্জ্বলতা"),
            "sound" to listOf("volume", "sound", "শব্দ", "সাউন্ড")
        )
        for ((settingKey, keywords) in settingsMatches) {
            val isMatch = keywords.any { kw ->
                clean.contains("open $kw") || clean.contains("$kw settings") || clean.contains("$kw সেটিংস")
            }
            if (isMatch) {
                val (success, message) = phoneCommandHelper.openSettingsScreen(settingKey)
                val reply = if (success) {
                    if (isBengali) "$settingKey সেটিংস খোলা হচ্ছে..." else "Opening $settingKey settings..."
                } else {
                    message
                }
                return OfflineCommandResult("SETTINGS", reply, target = settingKey)
            }
        }

        // 7. SIMPLE MATH EVALUATOR
        val mathRegex = Regex("""(\d+(?:\.\d+)?)\s*([\+\-\*\/xX÷])\s*(\d+(?:\.\d+)?)""")
        val mathMatch = mathRegex.find(clean)
        if (mathMatch != null) {
            val num1 = mathMatch.groupValues[1].toDoubleOrNull()
            val op = mathMatch.groupValues[2]
            val num2 = mathMatch.groupValues[3].toDoubleOrNull()
            if (num1 != null && num2 != null) {
                val result = when (op) {
                    "+", "plus" -> num1 + num2
                    "-", "minus" -> num1 - num2
                    "*", "x", "X" -> num1 * num2
                    "/", "÷" -> if (num2 != 0.0) num1 / num2 else Double.NaN
                    else -> null
                }
                if (result != null) {
                    val formatted = if (result.isNaN()) "Cannot divide by zero" else if (result % 1.0 == 0.0) result.toLong().toString() else "%.4f".format(result)
                    val reply = if (isBengali) "হিসাবের ফলাফল: $formatted" else "Calculated Result: $formatted"
                    return OfflineCommandResult("MATH", reply)
                }
            }
        }

        return null
    }

    override suspend fun processQuery(
        prompt: String,
        personality: AiPersonality,
        language: HyperLanguage
    ): AiResponse {
        // First check if this query can be fulfilled directly by the offline phone intelligence
        val offlineResult = checkOfflineCommand(prompt, language)
        if (offlineResult != null) {
            return AiResponse(
                text = offlineResult.replyText,
                isOffline = true,
                action = offlineResult.actionType,
                actionTarget = offlineResult.target,
                bannerNotice = null
            )
        }

        // Simulated intelligent neural engine with brief realistic thinking delay
        delay(600)

        val isBengali = language == HyperLanguage.BENGALI || containsBengali(prompt)
        val responseText = generateIntelligentResponse(prompt, personality, isBengali)

        return AiResponse(
            text = responseText,
            isOffline = false,
            action = null,
            actionTarget = null,
            bannerNotice = "Cloud Gemini brain requires Firebase activation. Operating in HYPER High-Efficiency Local Intelligence Mode."
        )
    }

    private fun generateIntelligentResponse(
        prompt: String,
        personality: AiPersonality,
        isBengali: Boolean
    ): String {
        val lower = prompt.lowercase(Locale.ROOT)

        val prefix = when (personality) {
            AiPersonality.CYBERPUNK -> if (isBengali) "[হাইপার নিউরাল কোর]: " else "[HYPER Neural Core]: "
            AiPersonality.HELPFUL -> if (isBengali) "[সহকারী]: " else "[Assistant]: "
            AiPersonality.GENIUS -> if (isBengali) "[অ্যানালিটিক্স ইঞ্জিন]: " else "[Analytical Engine]: "
            AiPersonality.WITTY -> if (isBengali) "[হাইপার স্পার্ক]: " else "[Hyper Spark]: "
        }

        val body: String = when {
            // Android & Mobile Tech
            lower.contains("android") || lower.contains("kotlin") || lower.contains("compose") -> {
                if (isBengali) {
                    "অ্যান্ড্রয়েড এবং জেটপ্যাক কম্পোজ (Jetpack Compose) আধুনিক মোবাইল অ্যাপ ডেভেলপমেন্টের সবচেয়ে শক্তিশালী আর্কিটেকচার। এটি ডিক্লারেটিভ ইউআই, স্টেট ম্যানেজমেন্ট এবং করুটিনের মাধ্যমে উচ্চ পারফরম্যান্স নিশ্চিত করে। আপনার কি কোটলিন বা কম্পোজ সম্পর্কিত কোনো কোড বা স্থাপত্য পরামর্শ প্রয়োজন?"
                } else {
                    "Jetpack Compose combined with Kotlin Coroutines and StateFlow provides modern declarative UI architecture for Android. It eliminates XML boilerplate, reactive state recompositions are seamless, and M3 design tokens allow high customizability. What specific Android concept or code implementation can I help you build?"
                }
            }

            // AI & Machine Learning
            lower.contains("ai") || lower.contains("artificial intelligence") || lower.contains("gemini") || lower.contains("এআই") -> {
                if (isBengali) {
                    "কৃত্রিম বুদ্ধিমত্তা (AI) এবং লার্জ ল্যাঙ্গুয়েজ মডেল (LLM) যেমন গুগল জেমিনি (Google Gemini) টেক্সট প্রসেসিং, কোড জেনারেশন এবং মাল্টিমোডাল ভিশনে বৈপ্লবিক পরিবর্তন এনেছে। হাইপার এআই ডিভাইস-লেভেল ইন্টেলিজেন্স ও ক্লাউড সক্ষমতার সমন্বয়ে পরিচালিত হয়।"
                } else {
                    "Artificial Intelligence and modern transformer architectures like Google Gemini process multimodal data (text, code, imagery, audio) via billions of attentional parameters. HYPER AI is engineered to bridge cloud neural models with device-level offline operational capabilities seamlessly."
                }
            }

            // Coding / Programming
            lower.contains("code") || lower.contains("function") || lower.contains("programming") || lower.contains("কোড") -> {
                if (isBengali) {
                    "আমি কোডিং ও সফটওয়্যার ডেভেলপমেন্টে সাহায্য করতে প্রস্তুত। আপনি পাইথন, কোটলিন, জাভাস্ক্রিপ্ট বা সি++ যে কোনো ভাষায় ফাংশন, অ্যালগরিদম বা ডিবাগিং সম্পর্কে প্রশ্ন করতে পারেন!"
                } else {
                    "Code synthesis module active. Whether you need Kotlin coroutines, async flow patterns, Python data processing, or algorithmic optimization, I can generate clean, idiomatic solutions. Provide your target specifications or snippet!"
                }
            }

            // Bangladesh / Geography
            lower.contains("bangladesh") || lower.contains("বাংলাদেশ") || lower.contains("dhaka") || lower.contains("ঢাকা") -> {
                if (isBengali) {
                    "বাংলাদেশ দক্ষিণ এশিয়ার একটি নদীমাতৃক ও দ্রুত বর্ধনশীল অর্থনীতির দেশ। রাজধানী ঢাকা এবং চট্টগ্রাম প্রধান বাণিজ্যিক বন্দর। এর প্রাকৃতিক সৌন্দর্যের অন্যতম সুন্দর নিদর্শন সুন্দরবন ও কক্সবাজারের দীর্ঘতম সমুদ্র সৈকত।"
                } else {
                    "Bangladesh is a vibrant nation in South Asia known for its rich delta waterways, booming technology sector, Sundarbans mangrove forest (home to Royal Bengal tigers), and Cox's Bazar, the world's longest unbroken natural sea beach."
                }
            }

            // Science & Space
            lower.contains("space") || lower.contains("universe") || lower.contains("planet") || lower.contains("বিজ্ঞান") || lower.contains("মহাকাশ") -> {
                if (isBengali) {
                    "মহাকাশ অসীম রহস্যে ঘেরা। আমাদের মিল্কিওয়ে গ্যালাক্সিতে কোটি কোটি সৌরজগত রয়েছে। আধুনিক জেমস ওয়েব স্পেস টেলিস্কোপ আমাদের মহাবিশ্বের প্রথম আলো ও আদিম ছায়াপথগুলো পর্যবেক্ষণ করতে সাহায্য করছে।"
                } else {
                    "Astrophysics telemetry: The observable universe spans over 93 billion light-years in diameter with over two trillion galaxies. Missions from the James Webb Space Telescope continue to uncover early cosmological structure formation, exoplanetary atmospheric spectra, and dark matter gravitational lensing."
                }
            }

            // General greeting / help
            else -> {
                if (isBengali) {
                    "আপনার প্রশ্নটি বুঝতে পেরেছি। হাইপার এআই আপনার যেকোনো তথ্য, ডিভাইস কমান্ড, অ্যাপ চালু করা এবং হিসাব-নিকাশে সহায়তা করতে সম্পূর্ণ প্রস্তুত। আপনি আরও বিস্তারিত জানতে চাইলে নির্দ্বিধায় বলুন!"
                } else {
                    "Query processed through HYPER reasoning core. I am tuned to help with device commands, system diagnostics, technical knowledge, code structures, and bilingual conversational assistance. How would you like to proceed?"
                }
            }
        }

        return "$prefix$body"
    }

    private fun containsBengali(text: String): Boolean {
        for (char in text) {
            val block = Character.UnicodeBlock.of(char)
            if (block == Character.UnicodeBlock.BENGALI) return true
        }
        return false
    }
}
