package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class HyperLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    BENGALI("bn", "Bengali", "বাংলা")
}

enum class AiPersonality(val id: String, val title: String, val subtitle: String) {
    CYBERPUNK("cyberpunk", "Cyberpunk HYPER", "Futuristic, sharp, and high-tech"),
    HELPFUL("helpful", "Friendly Companion", "Warm, respectful, and supportive"),
    GENIUS("genius", "Tech Genius", "Detailed, analytical, and logic-driven"),
    WITTY("witty", "Witty & Playful", "Humorous, clever, and entertaining")
}

data class HyperSettings(
    val language: HyperLanguage = HyperLanguage.ENGLISH,
    val personality: AiPersonality = AiPersonality.CYBERPUNK,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val autoSpeakResponses: Boolean = true,
    val soundEffectsEnabled: Boolean = true
)

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hyper_ai_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<HyperSettings> = _settings.asStateFlow()

    private fun loadSettings(): HyperSettings {
        val langCode = prefs.getString("language", HyperLanguage.ENGLISH.code) ?: HyperLanguage.ENGLISH.code
        val lang = HyperLanguage.entries.find { it.code == langCode } ?: HyperLanguage.ENGLISH

        val personalityId = prefs.getString("personality", AiPersonality.CYBERPUNK.id) ?: AiPersonality.CYBERPUNK.id
        val personality = AiPersonality.entries.find { it.id == personalityId } ?: AiPersonality.CYBERPUNK

        val speechRate = prefs.getFloat("speech_rate", 1.0f)
        val speechPitch = prefs.getFloat("speech_pitch", 1.0f)
        val autoSpeak = prefs.getBoolean("auto_speak", true)
        val soundEffects = prefs.getBoolean("sound_effects", true)

        return HyperSettings(
            language = lang,
            personality = personality,
            speechRate = speechRate,
            speechPitch = speechPitch,
            autoSpeakResponses = autoSpeak,
            soundEffectsEnabled = soundEffects
        )
    }

    fun setLanguage(language: HyperLanguage) {
        prefs.edit().putString("language", language.code).apply()
        _settings.value = _settings.value.copy(language = language)
    }

    fun setPersonality(personality: AiPersonality) {
        prefs.edit().putString("personality", personality.id).apply()
        _settings.value = _settings.value.copy(personality = personality)
    }

    fun setSpeechRate(rate: Float) {
        prefs.edit().putFloat("speech_rate", rate).apply()
        _settings.value = _settings.value.copy(speechRate = rate)
    }

    fun setSpeechPitch(pitch: Float) {
        prefs.edit().putFloat("speech_pitch", pitch).apply()
        _settings.value = _settings.value.copy(speechPitch = pitch)
    }

    fun setAutoSpeak(enabled: Boolean) {
        prefs.edit().putBoolean("auto_speak", enabled).apply()
        _settings.value = _settings.value.copy(autoSpeakResponses = enabled)
    }

    fun setSoundEffects(enabled: Boolean) {
        prefs.edit().putBoolean("sound_effects", enabled).apply()
        _settings.value = _settings.value.copy(soundEffectsEnabled = enabled)
    }
}
