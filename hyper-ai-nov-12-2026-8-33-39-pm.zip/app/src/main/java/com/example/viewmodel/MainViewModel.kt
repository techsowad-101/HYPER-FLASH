package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.HyperLanguage
import com.example.data.local.HyperSettings
import com.example.data.local.SettingsManager
import com.example.data.repository.AiRepository
import com.example.data.repository.AiRepositoryImpl
import com.example.data.repository.BatteryInfo
import com.example.data.repository.DeviceSpecs
import com.example.data.repository.PhoneCommandHelper
import com.example.service.voice.VoiceManager
import com.example.ui.components.OrbState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val chatDao = db.chatDao()
    val settingsManager = SettingsManager(application)
    val phoneCommandHelper = PhoneCommandHelper(application)
    private val aiRepository: AiRepository = AiRepositoryImpl(phoneCommandHelper)
    val voiceManager = VoiceManager(application)

    val settings: StateFlow<HyperSettings> = settingsManager.settings

    val chatMessages: StateFlow<List<ChatMessageEntity>> = chatDao.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Voice Orb, 1: AI Chat, 2: Phone Tools
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _batteryInfo = MutableStateFlow(phoneCommandHelper.getBatteryInfo())
    val batteryInfo: StateFlow<BatteryInfo> = _batteryInfo.asStateFlow()

    private val _deviceSpecs = MutableStateFlow(phoneCommandHelper.getDeviceSpecs())
    val deviceSpecs: StateFlow<DeviceSpecs> = _deviceSpecs.asStateFlow()

    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    // Determine current Orb state dynamically
    val orbState: StateFlow<OrbState> = combine(
        voiceManager.isListening,
        voiceManager.isSpeaking,
        _isThinking
    ) { listening, speaking, thinking ->
        when {
            listening -> OrbState.LISTENING
            thinking -> OrbState.THINKING
            speaking -> OrbState.SPEAKING
            else -> OrbState.IDLE
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OrbState.IDLE)

    init {
        // Wire voice recognition callback
        voiceManager.onSpeechRecognized = { text ->
            if (text.isNotBlank()) {
                sendMessage(text, fromVoice = true)
            }
        }

        // Periodic or initial refresh of device and battery info
        refreshTelemetry()
    }

    fun setSelectedTab(index: Int) {
        _selectedTab.value = index
    }

    fun setShowSettingsDialog(show: Boolean) {
        _showSettingsDialog.value = show
    }

    fun refreshTelemetry() {
        _batteryInfo.value = phoneCommandHelper.getBatteryInfo()
        _deviceSpecs.value = phoneCommandHelper.getDeviceSpecs()
    }

    fun toggleLanguage() {
        val current = settings.value.language
        val next = if (current == HyperLanguage.ENGLISH) HyperLanguage.BENGALI else HyperLanguage.ENGLISH
        settingsManager.setLanguage(next)
    }

    fun sendMessage(content: String, fromVoice: Boolean = false) {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return

        val currentLang = settings.value.language

        viewModelScope.launch {
            // 1. Insert User Message into Room
            val userMsg = ChatMessageEntity(
                sender = "USER",
                content = trimmed,
                language = currentLang.code
            )
            chatDao.insertMessage(userMsg)

            // 2. Set Thinking
            _isThinking.value = true

            try {
                // 3. Process with AI Repository
                val response = aiRepository.processQuery(
                    prompt = trimmed,
                    personality = settings.value.personality,
                    language = currentLang
                )

                // 4. Insert AI Response into Room
                val aiMsg = ChatMessageEntity(
                    sender = "AI",
                    content = response.text,
                    isOffline = response.isOffline,
                    language = currentLang.code,
                    commandAction = response.action
                )
                chatDao.insertMessage(aiMsg)

                // 5. If auto-speak or voice mode, speak response
                if (settings.value.autoSpeakResponses || fromVoice) {
                    voiceManager.speak(
                        text = response.text,
                        language = currentLang.code,
                        rate = settings.value.speechRate,
                        pitch = settings.value.speechPitch
                    )
                }
            } catch (e: Exception) {
                val errorMsg = if (currentLang == HyperLanguage.BENGALI) {
                    "বার্তা প্রসেস করতে ত্রুটি ঘটেছে: ${e.message}"
                } else {
                    "An error occurred while processing message: ${e.message}"
                }
                chatDao.insertMessage(
                    ChatMessageEntity(
                        sender = "AI",
                        content = errorMsg,
                        isOffline = true,
                        language = currentLang.code
                    )
                )
            } finally {
                _isThinking.value = false
            }
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            chatDao.clearAllMessages()
            voiceManager.stopSpeaking()
        }
    }

    fun startVoiceInput() {
        val langCode = settings.value.language.code
        voiceManager.startListening(langCode)
    }

    fun stopVoiceInput() {
        voiceManager.stopListening()
    }

    fun speakMessage(text: String) {
        val langCode = settings.value.language.code
        voiceManager.speak(
            text = text,
            language = langCode,
            rate = settings.value.speechRate,
            pitch = settings.value.speechPitch
        )
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun triggerQuickApp(appKey: String) {
        val (success, message) = phoneCommandHelper.openApp(appKey)
        viewModelScope.launch {
            val reply = if (settings.value.language == HyperLanguage.BENGALI) {
                if (success) "$appKey অ্যাপ্লিকেশন চালু হয়েছে।" else "সমস্যা: $message"
            } else {
                if (success) "Launching $appKey..." else "Error: $message"
            }
            chatDao.insertMessage(
                ChatMessageEntity(
                    sender = "AI",
                    content = reply,
                    isOffline = true,
                    language = settings.value.language.code,
                    commandAction = "OPEN_APP"
                )
            )
            if (settings.value.autoSpeakResponses) {
                speakMessage(reply)
            }
        }
    }

    fun triggerQuickSettings(settingsKey: String) {
        val (success, message) = phoneCommandHelper.openSettingsScreen(settingsKey)
        viewModelScope.launch {
            val reply = if (settings.value.language == HyperLanguage.BENGALI) {
                if (success) "$settingsKey সেটিংস খোলা হয়েছে।" else "সমস্যা: $message"
            } else {
                if (success) "Opening $settingsKey Settings..." else "Error: $message"
            }
            chatDao.insertMessage(
                ChatMessageEntity(
                    sender = "AI",
                    content = reply,
                    isOffline = true,
                    language = settings.value.language.code,
                    commandAction = "SETTINGS"
                )
            )
            if (settings.value.autoSpeakResponses) {
                speakMessage(reply)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
